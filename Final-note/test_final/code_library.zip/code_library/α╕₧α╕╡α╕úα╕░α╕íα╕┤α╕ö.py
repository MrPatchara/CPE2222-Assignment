# Input Example
myInput = int(input())
i = 1

# Output of Input Example
while i-1 < myInput:
    print("*" * i)
    i += 1