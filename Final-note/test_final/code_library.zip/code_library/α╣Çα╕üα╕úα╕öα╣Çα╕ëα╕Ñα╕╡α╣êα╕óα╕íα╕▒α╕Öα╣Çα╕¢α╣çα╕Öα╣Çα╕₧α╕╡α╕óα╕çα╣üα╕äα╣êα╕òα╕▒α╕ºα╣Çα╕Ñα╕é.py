myInput_1 = float(input())
myInput_2 = float(input())
myInput_3 = float(input())
myInput_4 = float(input())
myInput_5 = float(input())
result = (myInput_1 + myInput_2 + myInput_3 + myInput_4 + myInput_5) / 5

print(f"THAI = {myInput_1}")
print(f"MATH = {myInput_2}")
print(f"ENGLISH = {myInput_3}")
print(f"SCIENCE = {myInput_4}")
print(f"SPORT = {myInput_5}")
print("---")
print(f"GPA = {result}")