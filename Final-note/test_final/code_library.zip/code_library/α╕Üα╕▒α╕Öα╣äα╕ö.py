ladder = int(input())
i = 1

while i-1 < ladder:
  print("*" * i)
  i += 1