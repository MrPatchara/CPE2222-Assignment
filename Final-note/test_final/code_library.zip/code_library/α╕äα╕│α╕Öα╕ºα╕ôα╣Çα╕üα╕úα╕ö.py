#Input Example
myInput = int(input())

if myInput >= 80:
  print("A")

elif myInput >= 70:
   print("B")

elif myInput >= 60:
   print("C")

elif myInput >= 50:
   print("D")

else:
   print("F")