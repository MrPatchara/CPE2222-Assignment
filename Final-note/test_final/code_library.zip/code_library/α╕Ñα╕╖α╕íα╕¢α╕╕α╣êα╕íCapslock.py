text = str(input())

swip_text = text.swapcase()

print(swip_text)