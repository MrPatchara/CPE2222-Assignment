name = str(input())
birth = int(input())

if name == 'Sommai MeeMakMai':
  print(f"Welcome {name} to NongGipsy Pub")
elif name == 'A A':
  print(f"Welcome {name} to NongGipsy Pub")
elif birth > 2003:
  print("You shall not pass!")
elif birth <= 2003:
  print(f"Welcome {name} to NongGipsy Pub")
