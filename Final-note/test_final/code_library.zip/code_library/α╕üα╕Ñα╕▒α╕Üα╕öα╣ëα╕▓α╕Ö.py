text = str(input())

revers_text = text[::-1]

print(revers_text)