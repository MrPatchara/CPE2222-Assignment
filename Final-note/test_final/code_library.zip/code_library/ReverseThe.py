text = str(input())

w = text.split()
revers_w = w[::-1]
revers_text = ' '.join(revers_w)

print(revers_text)